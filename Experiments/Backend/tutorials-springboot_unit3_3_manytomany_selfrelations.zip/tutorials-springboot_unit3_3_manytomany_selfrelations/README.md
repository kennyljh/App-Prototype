# tutorials

ALL tutorials for cs309 will be in this repo.
Each topic will be on a different branch. Example: Mockito, WebSockets etc.
Each platform will be a FOLDER in this repo.
GIT wiki will be used for documentation.
Different levels will be in sub branches such as Mockito-1, Mockito-2 etc.

See the [wiki](https://git.las.iastate.edu/cs309/tutorials/wikis/home)

# How to start
There are two folders containing manytomany examples. Go to each and explore.

### Version Tested

|IntelliJ  | Project SDK | Springboot | Maven |
|----------|-------------|------------|-------|
|2023.2.2  |     17      | 3.1.4      | 3.6.3 |