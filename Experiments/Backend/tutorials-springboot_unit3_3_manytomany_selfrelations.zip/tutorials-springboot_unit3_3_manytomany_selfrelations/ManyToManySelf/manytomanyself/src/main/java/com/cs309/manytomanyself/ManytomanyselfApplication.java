package com.cs309.manytomanyself;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytomanyselfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManytomanyselfApplication.class, args);
	}

}
