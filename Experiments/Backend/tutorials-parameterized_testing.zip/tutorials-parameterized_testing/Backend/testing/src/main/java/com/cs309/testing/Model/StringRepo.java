package com.cs309.testing.Model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StringRepo extends JpaRepository<StringEntity, Long>{

}
