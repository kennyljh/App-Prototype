package com.cs309.testing.Model;

public interface IVolleyListener {
    public void onSuccess(String s);
    public void onError(String s);
}
