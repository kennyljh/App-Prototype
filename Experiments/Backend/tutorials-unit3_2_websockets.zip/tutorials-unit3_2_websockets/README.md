# Websocket Implementation with autowiring
When making a chat room, you would want to store the messages in the database. This example will demonstrate the easiest way to do so.
Read through the comments in ChatSocket file to learn more.

It's sufficient to use the index.html in Client_JS folder as UI to test the functionality of the server (just have to change the endpoint from '/websocket/' to '/chat/')

### Version Tested
|IntelliJ  | Project SDK | Springboot | Maven |
|----------|-------------|------------|-------|
|2021.2.4  |     11      | 3.1.4      | 3.6.3 |