package com.mycompany.model;

public enum Role {
    ADMIN, SUPPORT, AUDIT
}
